# Sentiment Analysis
A app that predicts sentiment of a user review based on the text entered by the user.
The model uses an LSTM architecture without pretrained word embeddings ran over 10 epochs
Instructions for Pycharm :
1) In project , add the html file in the templates folder
2) In the static folder add the css and js file for css js elements to work on webpage.Get it from here : https://materializecss.com/getting-started.html

